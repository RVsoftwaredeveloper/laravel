<?php
  
namespace App\Http\Controllers;
   
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
  
class ProductController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $products = Product::latest()->paginate(5);
    
        return view('products.index',compact('products'))
            ->with('i', (request()->input('page', 1) - 1) * 5);
    }
     
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('products.create');
    }
    
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        // using ajax show validation messsages
        $request->validate([
            'name' => 'required',
            'detail' => 'required',
            'file' => 'required|mimes:csv,txt,xlx,xls,pdf|max:2048',
        ]);



        //  if($request->hasFile('file')){
        //     // Get File
        //     $file = $request->file('file'); 
        //     // Get File Extention
        //     $fileGetFileExtension = $file->getClientOriginalExtension(); 
        //     // Create customized file name
        //     $fileName = Str::random(20).'_'.date('d_m_Y_h_i_s').'.'.$fileGetFileExtension; 
        //     // Save File to your storage folder
        //     Storage::disk('public')->put('files/'.$fileName,File::get($file));
        // }else{
        //     $fileName = null;
        // }

        //  Product::create([
        //     'name' => $request->get('name'),
        //     'detail' => $request->get('detail'),
        //     'filename' => $fileName,
        // ]);
     


        // using return response()->json([ 'status' => 'success', 'message' => 'Product created successfully.'],200);
        return redirect()->route('products.index')
                        ->with('success','Product created successfully.');
    }
     
    /**
     * Display the specified resource.
     *
     * @param  \App\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function show(Product $product)
    {
        return view('products.show',compact('product'));
    } 
     
    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function edit(Product $product)
    {        
        return view('products.edit',compact('product'));
    }
    
    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            'name' => 'required',
            'detail' => 'required',
            'file' => 'nullable|mimes:csv,txt,xlx,xls,pdf|max:2048',
        ]);
        $path = null;
        $getoldProductRow = Product::where('id',$id)->first();
        if($request->hasFile('file') === true){
            $name = $request->file('file')->getClientOriginalName();
            $path = $request->file('file')->store('public/files');
        }else{
            if($getoldProductRow->filename !== null){
                $path = $getoldProductRow->filename;
            }
        }

         Product::where('id',$id)->update([
            'name' => $request->get('name'),
            'detail' => $request->get('detail'),
            'filename' => $name,
        ]);

        return redirect()->route('products.index')
                        ->with('success','Product updated successfully');
    }
    
    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function destroy($id = NULL)
    {
        
        
        $brands = Product::findOrFail($id);
        $brands->delete();
    
        return redirect()->route('products.index')
                        ->with('success','Product deleted successfully');
    }

    public function destroys($id)
    {
      Product::delete($id);
      return response()->json(['success'=>"Product Deleted successfully.", 'tr'=>'tr_'.$id]);
    }

    public function deleteAll(Request $request)
    {
        $ids = $request->ids;
        Product::whereIn('id',explode(",",$ids))->delete();
        return response()->json(['success'=>"Products Deleted successfully."]);
    }
}